#ifndef __FCONTROLLERLISTENER_H__
#define __FCONTROLLERLISTENER_H__

#include "cocos2d.h"
USING_NS_CC;

class FControllerListener
{
public:
	virtual void setSimplePosition(float, float) = 0;
	virtual Point getCurPosition() = 0;

	virtual int getCurVal() = 0;
	
	virtual void removeFood() = 0;
	virtual bool checkRemoved() = 0;

	//addFood(Point);
};

#endif