#include "MoveController.h"
#include <iostream>
#include <math.h>
#define RANGE 6
#define RANGE_HALF 3

bool MoveController::init()
{
	this->Xspeed = 0;
	this->Yspeed = 0;
	/*������������*/
	setTouchEnabled(true);
	/*���ü���*/
	auto listener = EventListenerTouchOneByOne::create();
	listener->onTouchBegan = CC_CALLBACK_2(MoveController::onTouchBegan, this);
	Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);

	this->scheduleUpdate();
	return true;
}

void MoveController::update(float dt)
{
	if (pControllerListener == NULL)
		return;

	Point pos = pControllerListener->getCurPosition();
	if (pos.x + Xspeed < 31)
		Xspeed = rand()% RANGE_HALF;
	if (pos.x + Xspeed> 800-31)
		Xspeed = rand()% RANGE_HALF - RANGE_HALF;
	if (pos.y + Yspeed < 31)
		Yspeed = rand()% RANGE_HALF;
	if (pos.y + Yspeed > 500-31)
		Yspeed = rand()% RANGE_HALF - RANGE_HALF;

	pos.x += Xspeed;
	pos.y += Yspeed;
	
	pControllerListener->setSimplePosition(pos.x, pos.y);
}

void MoveController::setXSpeed(float speed)
{
	this->Xspeed = speed;
}

void MoveController::setYSpeed(float speed)
{
	this->Yspeed = speed;
}

bool MoveController::onTouchBegan(Touch* _touch, Event* _event)
{
	Point touchPos = _touch->getLocationInView();
	touchPos = Director::sharedDirector()->convertToGL(touchPos);

	Point curPos = pControllerListener->getCurPosition();

	int Xway = 0,Yway = 0;
	
	if (Xspeed != 0)
	{
		if (touchPos.x > curPos.x)
			Xway = (Xspeed > 0) ? 1 : -1;
		else Xway = (Xspeed > 0) ? -1 : 1;
	}
	else
	{
		while (Xspeed == 0)
		{
			Xspeed=rand() % RANGE - RANGE_HALF;
		}
		if (touchPos.x > curPos.x)
			Xway = (Xspeed > 0) ? 1 : -1;
		else Xway = (Xspeed > 0) ? -1 : 1;
	}
	setXSpeed(Xway*Xspeed);

	if (Yspeed != 0)
	{
		if (touchPos.y > curPos.y)
			Yway = (Yspeed > 0) ? 1 : -1;
		else Yway = (Yspeed > 0) ? -1 : 1;
	}
	else
	{
		while (Yspeed == 0)
		{
			Yspeed = rand() % RANGE - RANGE_HALF;
		}
		if (touchPos.y > curPos.y)
			Yway = (Yspeed > 0) ? 1 : -1;
		else Yway = (Yspeed > 0) ? -1 : 1;
	}
	setYSpeed(Yway*Yspeed);

	return true;
}

Point MoveController::getRolePosition()
{
	return pControllerListener->getCurPosition();
}

bool MoveController::touchOrNot(bool touch)
{
	if (touch == true)
		return true;
	else return false;
}