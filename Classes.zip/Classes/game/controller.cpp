#include "controller.h"

void controller::setControllerListener(ControllerListener* ControllerListener)
{
	this->pControllerListener = ControllerListener;
}

void controller::setFControllerListener(FControllerListener* ControllerListener)
{
	this->fControllerListener = ControllerListener;
}