#ifndef __CONTROLLER_H__
#define __CONTROLLER_H__

#include "cocos2d.h"
#include "ControllerListener.h"
#include "FControllerListener.h"
USING_NS_CC;

class controller :public Layer
{
public:
	//����
	void setControllerListener(ControllerListener*);
	void setFControllerListener(FControllerListener*);
public:
	ControllerListener* pControllerListener;
	FControllerListener* fControllerListener;
};

#endif