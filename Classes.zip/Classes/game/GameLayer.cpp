#include "GameLayer.h"
#include <fstream>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#define RANGE 6
#define RANGE_HALF 3
#define WIN_X 800
#define WIN_Y 500
#define STAR_NUM 25
#define CIRCLE_NUM 15
#define TRIANGLE_NUM 10
#define TIME 3000

bool GameLayer::init()
{
	if (!Layer::init())
	{
		return false;
	}

	//������ͼ
	gameMap = Sprite::create("game_bg.png");
	gameMap->setAnchorPoint(Vec2(0, 0));
	gameMap->setPosition(Vec2(0, 0));
	this->addChild(gameMap);

	/*���ز���ʳ��*/
	for (int i = 0;i < STAR_NUM;i++)
	{   //[100,124]
		_food=FoodManager::createFood(gameMap,1,i+100,createPosition());
		food.push_back(_food);
		foodCnt++;
		//Ϊʳ�����ײ�����
		_checker = CollisionChecker::create();
		checker.push_back(_checker);
		this->addChild(checker[foodCnt-1]);
		food[foodCnt-1]->setController(checker[foodCnt-1]);
		foodExist.push_back(true);
		/*end*/
	}
	for (int i = 0;i < CIRCLE_NUM;i++)
	{   //[125,139]
		_food = FoodManager::createFood(gameMap,2,i+125,createPosition());
		food.push_back(_food);
		foodCnt++;
		_checker = CollisionChecker::create();
		checker.push_back(_checker);
		this->addChild(checker[foodCnt - 1]);
		food[foodCnt - 1]->setController(checker[foodCnt - 1]);
		foodExist.push_back(true);
	}
	for (int i = 0;i < TRIANGLE_NUM;i++)
	{   //[140,149]
		_food = FoodManager::createFood(gameMap,3,i+140,createPosition());
		food.push_back(_food);
		foodCnt++;
		_checker = CollisionChecker::create();
		checker.push_back(_checker);
		this->addChild(checker[foodCnt - 1]);
		food[foodCnt - 1]->setController(checker[foodCnt - 1]);
		foodExist.push_back(true);
	}
	/*end*/


	/*�������player*/
	//���ļ�
	ifstream inIndexFile("index.dat", ios::in);
	if (!inIndexFile)
	{
		exit(1);
	}
	float index;
	inIndexFile >> index;
	//���ļ�����	
	int id = (int)index;
	srand(time(0));
	float x = rand() % 750 + 50;
	float y = rand() % 450 + 50;
	_player = BaseRole::createWithMap(gameMap,id,Vec2(x,y));
	player.push_back(_player);
	playerCnt++;
	/*end*/

	/*�������������ȷ������enemy*/
	int ID = rand() % 4;
	while (ID == id)
	{
		ID = rand() % 4;
	}
	float X = rand() % 750 + 50;
	float Y = rand() % 450 + 50;
	while (X == x&&Y == y)
	{
		X = rand() % 750 + 50;
		Y = rand() % 450 + 50;
	}
	_enemy = BaseRole::createWithMap(gameMap, ID,Vec2(X,Y));
	enemy.push_back(_enemy);
	enemyCnt++;
	/*end*/

	/*��������ƶ�������*/
	_pMove = MoveController::create();

	float x_speed = rand() % RANGE - RANGE_HALF;
	float y_speed = rand() % RANGE - RANGE_HALF;
	while (x_speed == 0 && y_speed == 0)
	{
		y_speed = rand() % RANGE - RANGE_HALF;
	}

	_pMove->setXSpeed(x_speed);
	_pMove->setYSpeed(y_speed);
	pMove.push_back(_pMove);
	/*�������ƶ����������ӵ��˳�����*/
	this->addChild(pMove[selectedPlayer]);
	/*�������ƶ��������󶨸����*/
	player[selectedPlayer]->setController(pMove[selectedPlayer]);
	/*end*/

	/*���������ƶ�������*/
	_eMove = SimpleMoveController::create();

	float x_Speed = rand() % RANGE - RANGE_HALF;
	float y_Speed = rand() % RANGE - RANGE_HALF;
	while (x_Speed == 0 && y_Speed == 0)
	{
		x_Speed = rand() % RANGE - RANGE_HALF;
		y_Speed = rand() % RANGE - RANGE_HALF;
	}

	_eMove->setXSpeed(x_Speed);
	_eMove->setYSpeed(y_Speed);
	eMove.push_back(_eMove);
	/*���ƶ����������ӵ��˳�����*/
	this->addChild(eMove[selectedEnemy]);
	/*���ƶ��������󶨸�����*/
	enemy[selectedEnemy]->setController(eMove[selectedEnemy]);

	/*������Һ͵��˵Ļ�Ծֵ*/
	//���
	if (id == 0)
		playerBar = Sprite::create("bar_blue_05.png");
	else if (id == 1)
		playerBar = Sprite::create("bar_pink_05.png");
	else if (id == 2)
		playerBar = Sprite::create("bar_orange_05.png");
	else if (id == 3)
		playerBar = Sprite::create("bar_yellow_05.png");
	playerBar->setAnchorPoint(Vec2(1.0f, 0.0f));
	playerBar->setPosition(Vec2(795, 467));
	this->addChild(playerBar);
	//����
	if (ID == 0)
		enemyBar = Sprite::create("bar_blue_05.png");
	else if (ID == 1)
		enemyBar = Sprite::create("bar_pink_05.png");
	else if (ID == 2)
		enemyBar = Sprite::create("bar_orange_05.png");
	else if (ID == 3)
		enemyBar = Sprite::create("bar_yellow_05.png");
	enemyBar->setAnchorPoint(Vec2(1.0f, 0.0f));
	enemyBar->setPosition(Vec2(795, 436));
	this->addChild(enemyBar);
	/*end*/

	this->scheduleUpdate();

	return true;
}

Point GameLayer::createPosition()
{
	srand(time(0));
	//x->[10,780]  y->[10,480]
	float x = rand() % (WIN_X - 20) + 10;
	float y = rand() % (WIN_Y - 20) + 10;
	for (int i = 0;i < (int)used.size();i++)
	{
		while (x == used[i].x&&y == used[i].y)
		{
			x = rand() % (WIN_X - 20) + 10;
			y = rand() % (WIN_Y - 20) + 10;
		}
	}
	used.push_back(Vec2(x, y));
	return Vec2(x, y);
}

void GameLayer::update(float dt)
{
	randCreateFood();

	updateBar();

	attack();
	checkPlayer();
	checkEnemy();

	createMori();
	removePlayer();
	removeEnemy();

	judge();
}

float GameLayer::getDistance(Point a, Point b)
{
	float dis2 = (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y);
	return (float)fabs(sqrt((double)dis2));
}

void GameLayer::checkPlayer()
{
	for (int i = 0;i < foodCnt;i++)
	{
		if (foodExist[i] == true)
		{
			Point playerPos = player[selectedPlayer]->getCurPosition();
			checker[i]->checkCollision(playerPos);
			if (food[i]->checkRemoved() == true)
			{
				player[selectedPlayer]->saveLastHP(player[selectedPlayer]->getHP());
				player[selectedPlayer]->updateHP(food[i]->getCurVal());
				this->removeChild(checker[i]);
				gameMap->removeChildByTag(i + 100);
				foodExist[i] = false;
				foodNotExist++;
				player[selectedPlayer]->playGrowAnimation();
			}
		}
	}
}

void GameLayer::checkEnemy()
{
	for (int i = 0;i < foodCnt;i++)
	{
		if (foodExist[i] == true)
		{
			Point enemyPos = enemy[selectedEnemy]->getCurPosition();
			checker[i]->checkCollision(enemyPos);
			if (food[i]->checkRemoved() == true)
			{
				enemy[selectedEnemy]->saveLastHP(enemy[selectedEnemy]->getHP());
				enemy[selectedEnemy]->updateHP(food[i]->getCurVal());
				this->removeChild(checker[i]);
				gameMap->removeChildByTag(i + 100);
				foodExist[i] = false;
				foodNotExist++;
				enemy[selectedEnemy]->playGrowAnimation();
			}
		}
	}
}

void GameLayer::attack()
{
	for (int i = 0;i < enemyCnt;i++)
	{
		Point playerPos = player[selectedPlayer]->getCurPosition();
		Point enemyPos = enemy[i]->getCurPosition();
		float dis = getDistance(playerPos, enemyPos);
		if (dis <= 60)
		{
			if (player[selectedPlayer]->getHP() < enemy[i]->getHP())
			{
				player[selectedPlayer]->saveLastHP(player[selectedPlayer]->getHP());
				player[selectedPlayer]->updateHP(-3);
				player[selectedPlayer]->playHurtAnimation();
				enemy[i]->saveLastHP(enemy[i]->getHP());
				enemy[i]->updateHP(3);
			}
			else if (player[selectedPlayer]->getHP() > enemy[i]->getHP())
			{
				player[selectedPlayer]->saveLastHP(player[selectedPlayer]->getHP());
				player[selectedPlayer]->updateHP(3);
				enemy[i]->saveLastHP(enemy[i]->getHP());
				enemy[i]->updateHP(-3);
				enemy[i]->playHurtAnimation();
			}
		}
	}
}

void GameLayer::updateBar()
{
	/*player*/
	int playerId = player[selectedPlayer]->getId();
	int playerLastHP = player[selectedPlayer]->getLastHP();
	int playerHP = player[selectedPlayer]->getHP();
	if (playerHP <= 0 && playerLastHP > 0)
	{
		playerHP = 1;
	}
	if (playerHP > 35 && playerLastHP <= 35)
	{
		playerHP = 35;
	}
	if (playerLastHP > 0 && playerHP > 0 && playerLastHP <= 35 && playerHP <= 35)
	{
		auto animation0 = Animation::create();
		if (playerId == 0)
		{
			if (playerLastHP <= playerHP)
			{
				for (int i = playerLastHP;i <= playerHP;i++)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_blue_%02d.png", i);
					animation0->addSpriteFrameWithFileName(szName);
				}
			}
			else
			{
				for (int i = playerLastHP;i >= playerHP;i--)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_blue_%02d.png", i);
					animation0->addSpriteFrameWithFileName(szName);
				}
			}
		}
		else if (playerId == 1)
		{
			if (playerLastHP <= playerHP)
			{
				for (int i = playerLastHP;i <= playerHP;i++)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_pink_%02d.png", i);
					animation0->addSpriteFrameWithFileName(szName);
				}
			}
			else
			{
				for (int i = playerLastHP;i >= playerHP;i--)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_pink_%02d.png", i);
					animation0->addSpriteFrameWithFileName(szName);
				}
			}
		}
		else if (playerId == 2)
		{
			if (playerLastHP <= playerHP)
			{
				for (int i = playerLastHP;i <= playerHP;i++)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_orange_%02d.png", i);
					animation0->addSpriteFrameWithFileName(szName);
				}
			}
			else
			{
				for (int i = playerLastHP;i >= playerHP;i--)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_orange_%02d.png", i);
					animation0->addSpriteFrameWithFileName(szName);
				}
			}
		}
		else if (playerId == 3)
		{
			if (playerLastHP <= playerHP)
			{
				for (int i = playerLastHP;i <= playerHP;i++)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_yellow_%02d.png", i);
					animation0->addSpriteFrameWithFileName(szName);
				}
			}
			else
			{
				for (int i = playerLastHP;i >= playerHP;i--)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_yellow_%02d.png", i);
					animation0->addSpriteFrameWithFileName(szName);
				}
			}
		}
		animation0->setDelayPerUnit(0.2f / 1.0f);
		animation0->setRestoreOriginalFrame(false);
		auto action0 = Animate::create(animation0);
		playerBar->runAction(Sequence::create(action0, action0->reverse(), NULL));
	}
	
	/*enemy*/
	int enemyId = enemy[selectedEnemy]->getId();
	int enemyLastHP = enemy[selectedEnemy]->getLastHP();
	int enemyHP = enemy[selectedEnemy]->getHP();
	if (enemyHP <= 0 && enemyLastHP > 0)
	{
		enemyHP = 1;
	}
	if (enemyHP > 35 && enemyLastHP <= 35)
	{
		enemyHP = 35;
	}
	if (enemyLastHP > 0 && enemyHP > 0 && enemyLastHP <= 35 && enemyHP <= 35)
	{
		auto animation = Animation::create();
		if (enemyId == 0)
		{
			if (enemyLastHP <= enemyHP)
			{
				for (int i = enemyLastHP;i <= enemyHP;i++)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_blue_%02d.png", i);
					animation->addSpriteFrameWithFileName(szName);
				}
			}
			else
			{
				for (int i = enemyLastHP;i >= enemyHP;i--)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_blue_%02d.png", i);
					animation->addSpriteFrameWithFileName(szName);
				}
			}
		}
		else if (enemyId == 1)
		{
			if (enemyLastHP <= enemyHP)
			{
				for (int i = enemyLastHP;i <= enemyHP;i++)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_pink_%02d.png", i);
					animation->addSpriteFrameWithFileName(szName);
				}
			}
			else
			{
				for (int i = enemyLastHP;i >= enemyHP;i--)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_pink_%02d.png", i);
					animation->addSpriteFrameWithFileName(szName);
				}
			}
		}
		else if (enemyId == 2)
		{
			if (enemyLastHP <= enemyHP)
			{
				for (int i = enemyLastHP;i <= enemyHP;i++)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_orange_%02d.png", i);
					animation->addSpriteFrameWithFileName(szName);
				}
			}
			else
			{
				for (int i = enemyLastHP;i >= enemyHP;i--)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_orange_%02d.png", i);
					animation->addSpriteFrameWithFileName(szName);
				}
			}
		}
		else if (enemyId == 3)
		{
			if (enemyLastHP <= enemyHP)
			{
				for (int i = enemyLastHP;i <= enemyHP;i++)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_yellow_%02d.png", i);
					animation->addSpriteFrameWithFileName(szName);
				}
			}
			else
			{
				for (int i = enemyLastHP;i >= enemyHP;i--)
				{
					char szName[50] = { 0 };
					sprintf(szName, "bar_yellow_%02d.png", i);
					animation->addSpriteFrameWithFileName(szName);
				}
			}
		}
		animation->setDelayPerUnit(0.2f / 1.0f);
		animation->setRestoreOriginalFrame(false);
		auto action = Animate::create(animation);
		enemyBar->runAction(Sequence::create(action, action->reverse(), NULL));
	}
}

void GameLayer::randCreateFood()
{
	if (foodNotExist >= notExist)
	{
		srand(time(0));
		int type = rand() % 2 + 1;
		if (foodNotExist >= 10 && foodNotExist % 10 == 0)
		{
			type = 3;
		}
		/*���ز���ʳ��*/
		_food = FoodManager::createFood(gameMap, type, foodCnt+100, createPosition());
		food.push_back(_food);
		foodCnt++;
		//Ϊʳ�����ײ�����
		_checker = CollisionChecker::create();
		checker.push_back(_checker);
		this->addChild(checker[foodCnt - 1]);
		food[foodCnt - 1]->setController(checker[foodCnt - 1]);
		foodExist.push_back(true);
		/*end*/
		notExist += 1;
	}
}

void GameLayer::createMori()
{
	srand(time(0));
	//player
	for (int i = 0;i < playerCnt;i++)
	{
		if (player[i]->getHP() >= 35)
		{
			int id = player[i]->getId();
			
			float x = rand() % 750 + 50;
			float y = rand() % 450 + 50;
			_player = BaseRole::createWithMap(gameMap, id,Vec2(x,y));
			player.push_back(_player);
			playerCnt++;
			/*�����µ�����ƶ�������*/
			_ppMove = SimpleMoveController::create();

			float x_speed = rand() % RANGE - RANGE_HALF;
			float y_speed = rand() % RANGE - RANGE_HALF;
			while (x_speed == 0 && y_speed == 0)
			{
				y_speed = rand() % RANGE - RANGE_HALF;
			}

			_ppMove->setXSpeed(x_speed);
			_ppMove->setYSpeed(y_speed);
			ppMove.push_back(_ppMove);
			/*�������ƶ����������ӵ��˳�����*/
			this->addChild(ppMove[playerCnt - 2]);
			/*�������ƶ��������󶨸������*/
			player[playerCnt - 1]->setController(ppMove[playerCnt - 2]);
			/*end*/

			/*�ָ���������*/
			player[i]->saveLastHP(5);
			player[i]->resetHP(5);
		}
	}
	//enemy
	for (int i = 0;i < enemyCnt;i++)
	{
		if (enemy[i]->getHP() >= 35)
		{
			int id = enemy[i]->getId();
			float x = rand() % 750 + 50;
			float y = rand() % 450 + 50;
			_enemy = BaseRole::createWithMap(gameMap, id,Vec2(x,y));
			enemy.push_back(_enemy);
			enemyCnt++;
			/*�����µĵ����ƶ�������*/
			_eMove = SimpleMoveController::create();

			float x_Speed = rand() % RANGE - RANGE_HALF;
			float y_Speed = rand() % RANGE - RANGE_HALF;
			while (x_Speed == 0 && y_Speed == 0)
			{
				x_Speed = rand() % RANGE - RANGE_HALF;
				y_Speed = rand() % RANGE - RANGE_HALF;
			}

			_eMove->setXSpeed(x_Speed);
			_eMove->setYSpeed(y_Speed);
			eMove.push_back(_eMove);
			/*���ƶ����������ӵ��˳�����*/
			this->addChild(eMove[enemyCnt - 1]);
			/*���ƶ��������󶨸��µ���*/
			enemy[enemyCnt - 1]->setController(eMove[enemyCnt - 1]);
			/*end*/

			/*�ָ���������*/
			enemy[i]->saveLastHP(5);
			enemy[i]->resetHP(5);
		}

	}
}

void GameLayer::removePlayer()
{
	for (int i = 0;i < playerCnt;i++)
	{
		if (player[i]->getHP() <= 0)
		{
			if (i != 0)
				player[i]->playDead();
			playerDead++;
		}
	}
	
	if (player[selectedPlayer]->getHP() <= 0)
	{
		int index = 1;
		bool ex = false;
		for (;index < playerCnt;index++)
		{
			if (player[index]->getHP() > 0)
			{
				player[index]->playDead();
				ex = true;
				break;
			}
		}
		if (ex)
		{
			player[selectedPlayer]->resetHP(player[index]->getHP());
			player[selectedPlayer]->saveLastHP(player[index]->getLastHP());
		}
	}
	if (playerCnt - playerDead == 0)
	{
		playerLose = true;
		return;
	}
}

void GameLayer::removeEnemy()
{
	for (int i = 0;i < enemyCnt;i++)
	{
		if (enemy[i]->getHP() <= 0)
		{
			enemy[i]->playDead();
			enemyDead++;
		}
	}
	if (enemyCnt - enemyDead == 0)
	{
		enemyLose = true;
		return;
	}
}

void GameLayer::judge()
{
	if (playerLose == true)
	{
		ptr->toFailedScene();
	}
	if (enemyLose == true)
	{
		ptr->toSuccessfulScene();
	}
}