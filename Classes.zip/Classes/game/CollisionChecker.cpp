#include "CollisionChecker.h"

bool CollisionChecker::init()
{
	return true;
}

float CollisionChecker::getDistance(Point a, Point b)
{
	float dis2 = (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y);
	return (float)fabs(sqrt((double)dis2));
}

void CollisionChecker::checkCollision(Point curPos)
{
	Point pos;
	float dis = 0;
	pos = fControllerListener->getCurPosition();
	dis = getDistance(curPos, pos);
	if (dis < 30)
		fControllerListener->removeFood();
}