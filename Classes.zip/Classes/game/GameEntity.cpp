#include "GameEntity.h"
#include <fstream>

void GameEntity::setRole(Role role)
{
	this->_role = role;
}

void GameEntity::setController(controller* _controller)
{
	this->_controller = _controller;
	_controller->setControllerListener(this);
}

void GameEntity::setSimplePosition(float x, float y)
{
	if (_role.sprite)
	{
		_role.sprite->setPosition(Vec2(x, y));
	}
	else return;
}

Point GameEntity::getCurPosition()
{
	if (_role.sprite)
	{
		return _role.sprite->getPosition();
	}
	return Point(0, 0);
}

void GameEntity::updateHP(int hp)
{
	if (_role.sprite)
	{
		_role.HP += hp;
	}
	else return;
}

void GameEntity::saveLastHP(int hp)
{
	if (_role.sprite)
	{
		_role.lastHP = hp;
	}
	else return;
}

int GameEntity::getLastHP()
{
	if (_role.sprite)
	{
		return _role.lastHP;
	}
	else return 0;
}

void GameEntity::resetHP(int hp)
{
	if (_role.sprite)
	{
		_role.HP = hp;
	}
	else return ;
}

int GameEntity::getHP()
{
	if (_role.sprite)
	{
		return _role.HP;
	}
	else return 0;
}

int GameEntity::getId()
{
	if (_role.sprite)
	{
		return _role.id;
	}
	else return -1;
}

void GameEntity::playGrowAnimation()
{
	auto animation = Animation::create();
	
	if(_role.id == 0)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_blue_grow.png");
		animation->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 1)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_pink_grow.png");
		animation->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 2)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_orange_grow.png");
		animation->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 3)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_yellow_grow.png");
		animation->addSpriteFrameWithFileName(szName);
	}
	
	animation->setDelayPerUnit(0.6f / 1.0f);
	animation->setRestoreOriginalFrame(false);
	auto action = Animate::create(animation);
	_role.sprite->runAction(action);

	auto animation0 = Animation::create();

	if (_role.id == 0)
	{
		char szName[50] = { 0 };
		sprintf(szName, "mori_blue.png");
		animation0->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 1)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_pink.png");
		animation0->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 2)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_orange.png");
		animation0->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 3)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_yellow.png");
		animation0->addSpriteFrameWithFileName(szName);
	}

	animation0->setDelayPerUnit(1.0f / 1.0f);
	animation0->setRestoreOriginalFrame(true);
	auto action0 = Animate::create(animation0);
	_role.sprite->runAction(Sequence::create(action0, action0->reverse(), NULL));
}

void GameEntity::playHurtAnimation()
{
	auto animation = Animation::create();

	if (_role.id == 0)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_blue_hurt.png");
		animation->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 1)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_pink_hurt.png");
		animation->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 2)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_orange_hurt.png");
		animation->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 3)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_yellow_hurt.png");
		animation->addSpriteFrameWithFileName(szName);
	}

	animation->setDelayPerUnit(0.6f / 1.0f);
	animation->setRestoreOriginalFrame(false);
	auto action = Animate::create(animation);
	_role.sprite->runAction(action);

	auto animation0 = Animation::create();

	if (_role.id == 0)
	{
		char szName[50] = { 0 };
		sprintf(szName, "mori_blue.png");
		animation0->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 1)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_pink.png");
		animation0->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 2)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_orange.png");
		animation0->addSpriteFrameWithFileName(szName);
	}
	else if (_role.id == 3)
	{
		char szName[100] = { 0 };
		sprintf(szName, "mori_yellow.png");
		animation0->addSpriteFrameWithFileName(szName);
	}

	animation0->setDelayPerUnit(1.0f / 1.0f);
	animation0->setRestoreOriginalFrame(true);
	auto action0 = Animate::create(animation0);
	_role.sprite->runAction(Sequence::create(action0, action0->reverse(), NULL));
}

void GameEntity::playDead()
{
	_role.HP = 0;
	auto texture = CCTextureCache::sharedTextureCache()->addImage("none.png");
	_role.sprite->setTexture(texture);
}