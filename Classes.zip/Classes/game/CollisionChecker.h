#ifndef __COLLISIONCHECKER_H__
#define __COLLISIONCHECKER_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include "cocostudio/CocoStudio.h"
#include "MoveController.h"
#include "SimpleMoveController.h"
#include "controller.h"
#include "FoodEntity.h"
#include "FoodManager.h"
using namespace std;
USING_NS_CC;

class CollisionChecker:public controller
{
public:
	CREATE_FUNC(CollisionChecker);
	virtual bool init();
	/*��ײ��⼰����*/
	void checkCollision(Point);

private:
	float getDistance(Point, Point);
};

#endif