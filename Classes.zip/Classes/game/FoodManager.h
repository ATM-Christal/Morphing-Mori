#ifndef __BASEMANAGER_H__
#define __BASEMANAGER_H__

#include <iostream>
#include <vector>
#include <string>
#include "cocos2d.h"
#include "FoodEntity.h"
using namespace std;
USING_NS_CC;

class FoodManager:public FoodEntity
{
public:
	static FoodManager* createFood(Sprite*, int, int, Point);
	bool initFood(Sprite*,int,int,Point);

private:
	string str_plist[3] = { "Star0.plist","Circle0.plist","Triangle0.plist" };
	string str_png[3] = { "star.png","circle.png","triangle.png" };
};

#endif