#ifndef __SIMPLEMOVECONTROLLER_H__
#define __SIMPLEMOVECONTROLLER_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include "cocostudio/CocoStudio.h"
#include "controller.h"
using namespace std;
USING_NS_CC;

class SimpleMoveController :public controller
{
public:
	CREATE_FUNC(SimpleMoveController);
	virtual bool init();
	virtual void update(float);
	/*����X��Y�����ƶ��ٶ�*/
	void setXSpeed(float);
	void setYSpeed(float);
private:
	float Xspeed;
	float Yspeed;
};

#endif