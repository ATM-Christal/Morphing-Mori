/*********************************/
/*           Mori��              */
/*********************************/

#ifndef __BASEROLE_H__
#define __BASEROLE_H__

#include <iostream>
#include <vector>
#include "GameEntity.h"
#include "FoodEntity.h"

class BaseRole :public GameEntity
{
public:
	static BaseRole* createWithMap(Sprite*, int, Point);
	bool initWithMap(Sprite*, int, Point);

	void setSimplePosition(float,float);
	void updateHP(int);

private:
	string str_plist[4] = { "Mori_Blue0.plist","Mori_Pink0.plist","Mori_Orange0.plist","Mori_Yellow0.plist" };
	string str_png[4] = { "mori_blue.png","mori_pink.png","mori_orange.png","mori_yellow.png" };
};

#endif