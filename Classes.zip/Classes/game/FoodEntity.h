#ifndef __FOODENTITY_H__
#define __FOODENTITY_H__

#include <iostream>
#include <vector>
#include "cocos2d.h"
#include "controller.h"
#include "FControllerListener.h"
using namespace std;
USING_NS_CC;

struct Food
{
	int val;
	Sprite* sprite;
};

class FoodEntity :public FControllerListener
{
public:
	void setFood(Food);
	void setController(controller*);
	//�����麯��
	virtual void setSimplePosition(float, float);
	virtual Point getCurPosition();
	virtual int getCurVal();
	virtual void removeFood();
	virtual bool checkRemoved();

protected:
	Food _food;

	controller* _controller;

	Sprite* gameMap;
};

#endif