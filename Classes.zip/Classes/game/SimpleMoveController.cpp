#include "SimpleMoveController.h"
#define RANGE 6
#define RANGE_HALF 3

bool SimpleMoveController::init()
{
	this->Xspeed = 0;
	this->Yspeed = 0;

	this->scheduleUpdate();
	return true;
}

void SimpleMoveController::update(float dt)
{
	if (pControllerListener == NULL)
		return;

	Point pos = pControllerListener->getCurPosition();
	if (pos.x + Xspeed < 31)
		Xspeed = rand() % RANGE_HALF;
	if (pos.x + Xspeed> 800 - 31)
		Xspeed = rand() % RANGE_HALF - RANGE_HALF;
	if (pos.y + Yspeed < 31)
		Yspeed = rand() % RANGE_HALF;
	if (pos.y + Yspeed > 500 - 31)
		Yspeed = rand() % RANGE_HALF - RANGE_HALF;
	if (Xspeed == 0 || Yspeed == 0)
	{
		Xspeed = rand() % RANGE - RANGE_HALF;
		Yspeed = rand() % RANGE - RANGE_HALF;
	}

	pos.x += Xspeed;
	pos.y += Yspeed;

	pControllerListener->setSimplePosition(pos.x, pos.y);
}

void SimpleMoveController::setXSpeed(float speed)
{
	this->Xspeed = speed;
}

void SimpleMoveController::setYSpeed(float speed)
{
	this->Yspeed = speed;
}