#ifndef __CONTROLLERLISTENER_H__
#define __CONTROLLERLISTENER_H__

#include "cocos2d.h"
USING_NS_CC;

class ControllerListener
{
public:
	virtual void setSimplePosition(float, float) = 0;

	virtual Point getCurPosition() = 0;

	virtual void updateHP(int) = 0;
	virtual void saveLastHP(int) = 0;
	virtual int getLastHP() = 0;
	virtual void resetHP(int) = 0;
	virtual int getHP() = 0;
	virtual int getId() = 0;

	virtual void playGrowAnimation() = 0;
	virtual void playHurtAnimation() = 0;
	virtual void playDead() = 0;
};

#endif