#include "FoodManager.h"
#include <stdlib.h>
#include <time.h>

FoodManager* FoodManager::createFood(Sprite* map,int _val,int id,Point pos)
{
	FoodManager* foodManager = new FoodManager();
	if (foodManager && foodManager->initFood(map,_val,id,pos))
	{   //����ɫ�����Զ��ͷų�
		//baseRole->autorelease();
	}
	else
	{
		CC_SAFE_DELETE(foodManager);
		//return nullptr;
	}
	return foodManager;
}

bool FoodManager::initFood(Sprite* map,int _val,int tag,Point pos)
{
	SpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile(str_plist[_val-1]);
	_food.sprite = Sprite::createWithSpriteFrameName(str_png[_val-1]);
	_food.val = _val;
	_food.sprite->setAnchorPoint(Vec2(0.5f, 0.5f));
	_food.sprite->setPosition(Vec2(pos.x, pos.y));

	_food.sprite->setTag(tag);
	map->addChild(_food.sprite,0);
	setFood(_food);

	this->gameMap = map;
	return true;
}