#ifndef __GAMEENTITY_H__
#define __GAMEENTITY_H__

#include <iostream>
#include <vector>
#include "cocos2d.h"
#include "controller.h"
#include "ControllerListener.h"
using namespace std;
USING_NS_CC;

struct Role
{
	int id;
	int lastHP;
	int HP;
	Sprite* sprite;
};

class GameEntity :public ControllerListener
{
public:
	void setRole(Role);
	void setController(controller*);

	//���ƴ��麯��
	virtual void setSimplePosition(float, float);
	virtual Point getCurPosition();
	virtual void updateHP(int);
	virtual void saveLastHP(int);
	virtual int getLastHP();
	virtual void resetHP(int);
	virtual int getHP();
	virtual int getId();
	virtual void playGrowAnimation();
	virtual void playHurtAnimation();
	virtual void playDead();

protected:
	Role _role;

	controller* _controller;

	Sprite* gameMap;
};

#endif