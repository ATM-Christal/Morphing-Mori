#ifndef __MOVECONTROLLER_H__
#define __MOVECONTROLLER_H__

#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include "cocostudio/CocoStudio.h"
#include "controller.h"
using namespace std;
USING_NS_CC;

class MoveController :public controller
{
public:
	CREATE_FUNC(MoveController);
	virtual bool init();
	virtual void update(float);
	/*�����¼�*/
	virtual bool onTouchBegan(Touch*, Event*);
	/*����X��Y�����ƶ��ٶ�*/
	void setXSpeed(float);
	void setYSpeed(float);

	Point getRolePosition();
	bool touchOrNot(bool);
private:
	float Xspeed;
	float Yspeed;
};

#endif