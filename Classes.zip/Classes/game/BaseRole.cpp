#include "BaseRole.h"
#include <stdlib.h>
#include <time.h>
using namespace std;

BaseRole* BaseRole::createWithMap(Sprite* gameMap,int id,Point pos)
{
	BaseRole* baseRole = new BaseRole();
	if (baseRole && baseRole->initWithMap(gameMap,id,pos))
	{   //����ɫ�����Զ��ͷų�
		//baseRole->autorelease();
	}
	else
	{
		CC_SAFE_DELETE(baseRole);
		//return nullptr;
	}
	return baseRole;
}

bool BaseRole::initWithMap(Sprite* gameMap,int id,Point pos)
{
	//����id��ȷ��role
	SpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile(str_plist[id]);
	_role.sprite = Sprite::createWithSpriteFrameName(str_png[id]);
	_role.id = id;
	_role.lastHP = 5;
	_role.HP = 5;
	_role.sprite->setAnchorPoint(Vec2(0.5f, 0.5f));
	_role.sprite->setPosition(Vec2(pos.x, pos.y));

	gameMap->addChild(_role.sprite, 1, id);
	setRole(_role);
	//��ɫȷ�����

	/*�����ͼ������*/
	this->gameMap = gameMap;
	return true;
}

void BaseRole::setSimplePosition(float x, float y)
{
	GameEntity::setSimplePosition(x,y);
}

void BaseRole::updateHP(int hp)
{
	GameEntity::updateHP(hp);
}