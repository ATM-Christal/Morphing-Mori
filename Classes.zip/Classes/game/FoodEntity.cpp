#include "FoodEntity.h"

void FoodEntity::setFood(Food food)
{
	this->_food = food;
}

void FoodEntity::setController(controller* _controller)
{
	this->_controller = _controller;
	_controller->setFControllerListener(this);
}

void FoodEntity::setSimplePosition(float x, float y)
{
	if (_food.sprite)
		_food.sprite->setPosition(Vec2(x, y));
}

Point FoodEntity::getCurPosition()
{
	if (_food.sprite)
		return _food.sprite->getPosition();
	else return Point(0, 0);
}

void FoodEntity::removeFood()
{
	_food.sprite = nullptr;
}

bool FoodEntity::checkRemoved()
{
	if (_food.sprite)
		return false;
	else return true;
}

int FoodEntity::getCurVal()
{
	return _food.val;
}