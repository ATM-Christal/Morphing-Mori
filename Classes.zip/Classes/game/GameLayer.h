/****************************************************************/
/*                        ������Ϸ����                          */
/****************************************************************/
#ifndef __GAMELAYER_H__
#define __GAMELAYER_H__

#include <iostream>
#include <vector>
#include <string>
#include "cocos2d.h"
#include "ui/CocosGUI.h"
#include "cocostudio/CocoStudio.h"
#include "SceneManager.h"
#include "ChooseLayer.h"
#include "MapLayer.h"
#include "BaseRole.h"
#include "GameEntity.h"
#include "MoveController.h"
#include "SimpleMoveController.h"
#include "FoodManager.h"
#include "CollisionChecker.h"
using namespace std;
USING_NS_CC;

class GameLayer :public Layer
{
public:
	CREATE_FUNC(GameLayer);
	virtual bool init();
	virtual void update(float);

	float getDistance(Point,Point);
	void checkPlayer();
	void checkEnemy();
	void attack();
	void randCreateFood();

	void createMori();
	void removePlayer();
	void removeEnemy();

	void judge();
public:
	SceneManager* ptr;
private:
	Sprite* gameMap;

	int foodCnt = 0;
	int foodNotExist = 0;
	int notExist = 3;
	vector<bool> foodExist;
	FoodManager* _food;
	vector<FoodManager*> food;
	CollisionChecker* _checker;
	vector<CollisionChecker*> checker;

	vector<Point> used;
	Point createPosition();

	int playerCnt = 0;
	int enemyCnt = 0;
	int selectedPlayer = 0;
	int selectedEnemy = 0;
	BaseRole* _player;
	BaseRole* _enemy;
	vector<BaseRole*> player;
	vector<BaseRole*> enemy;
	MoveController* _pMove;
	SimpleMoveController* _ppMove;
	SimpleMoveController* _eMove;
	vector<MoveController*> pMove;
	vector<SimpleMoveController*> ppMove;
	vector<SimpleMoveController*> eMove;

	Sprite* playerBar;
	Sprite* enemyBar;
	void updateBar();

	int playerDead = 0;
	int enemyDead = 0;
	bool playerLose = false;
	bool enemyLose = false;
};

#endif