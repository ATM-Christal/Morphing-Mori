#ifndef __MAPLAYER_H__
#define __MAPLAYER_H__

#include <iostream>
#include "cocos2d.h"
#include "SceneManager.h"
#include "ui/CocosGUI.h"
#include "cocostudio/CocoStudio.h"
USING_NS_CC;
using namespace ui;

class MapLayer :public Layer
{
public:
	CREATE_FUNC(MapLayer);
	virtual bool init();

	void setBackGround(const char*);

private:
	//���뱳��ͼƬ
	ImageView* bgImageView;
};

#endif