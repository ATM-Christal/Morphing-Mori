/************************************************************************/
/*         ������Ϸ��鳡����ʵ�ִ���Ϸ��鷵����Ϸ��ҳ��ת��           */
/************************************************************************/

#ifndef __INTROLAYER_H__
#define __INTROLAYER_H__

#include <iostream>
#include "cocos2d.h"
#include "SceneManager.h"
#include "MenuLayer.h"
#include "ui/CocosGUI.h"
#include "cocostudio/CocoStudio.h"
USING_NS_CC;

class IntroLayer :public Layer, public SceneManager
{
public:
	CREATE_FUNC(IntroLayer);
	virtual bool init();
	void touchCallBack(Ref* , Widget::TouchEventType);
public:
	SceneManager* ptr;
};

#endif