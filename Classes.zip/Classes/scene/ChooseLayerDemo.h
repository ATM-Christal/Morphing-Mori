/**********************************************************************/
/*            ʵ�ֲ˵����ѡ���Լ�ת������ʽ��Ϸ����                */
/**********************************************************************/

#ifndef __CHOOSELAYERDEMO_H__
#define __CHOOSELAYERDEMO_H__

#include <iostream>
#include <string>
#include "cocos2d.h"
#include "SceneManager.h"
#include "ChooseLayer.h"
#include "ui/CocosGUI.h"
#include "cocostudio/CocoStudio.h"
using namespace std;
using namespace ui;
using namespace cocostudio;
USING_NS_CC;

class ChooseLayerDemo :public Layer
{
public:
	CREATE_FUNC(ChooseLayerDemo);
	static Scene* createScene();
	virtual bool init();
	void touchCallBack(Ref*, Widget::TouchEventType);

	//ѡ�����ص�
	void menuCloseCallBack(Ref*);
	void menuItem1CallBack(Ref*);
	void menuItem2CallBack(Ref*);
	void menuItem3CallBack(Ref*);
	void menuItem4CallBack(Ref*);

	void hideAllSprite();
	Sprite* sprite[4];

public:
	SceneManager* ptr;
};

#endif
