#ifndef __FAILEDLAYER_H__
#define __FAILEDLAYER_H__

#include <iostream>
#include "cocos2d.h"
#include "SceneManager.h"
#include "GameLayer.h"
#include "ui/CocosGUI.h"
#include "cocostudio/CocoStudio.h"
USING_NS_CC;

class FailedLayer :public Layer, public SceneManager
{
public:
	CREATE_FUNC(FailedLayer);
	virtual bool init();
	void touchCallBack(Ref*, Widget::TouchEventType);
public:
	SceneManager* ptr;
};

#endif