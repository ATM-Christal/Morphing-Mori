#include "SceneManager.h"
#include "MenuLayer.h"
#include "GameLayer.h"
#include "IntroLayer.h"
#include "ChooseLayer.h"
#include "ChooseLayerDemo.h"
#include "SuccessfulLayer.h"
#include "FailedLayer.h"

void SceneManager::createScene()
{
	//������ʼ���泡��
	faceScene = Scene::create();
	//������
	auto menuLayer = MenuLayer::create();
	//������뵽������
	menuLayer->ptr = this;
	faceScene->addChild(menuLayer);

	mciSendStringA("open F:/cocos/project/MorphingMori/Resources/spring.mp3 repeat", NULL, 0, 0);
	mciSendStringA("play F:/cocos/project/MorphingMori/Resources/spring.mp3 repeat", NULL, 0, 0);
}

void SceneManager::toChooseScene()
{
	//����ѡ���ɫ������ʹ�õ�������г�����ת��
	chooseScene = Scene::create();
	ChooseLayerDemo* chooseLayer = ChooseLayerDemo::create();
	chooseLayer->ptr = this;
	chooseScene->addChild(chooseLayer);
	Director::getInstance()->replaceScene(chooseScene);
}

void SceneManager::toGameScene()
{
	//������Ϸ������ʹ�õ�������г�����ת��
	gameScene = Scene::create();
	GameLayer* gameLayer = GameLayer::create();
	gameLayer->ptr = this;
	gameScene->addChild(gameLayer);
	Director::getInstance()->replaceScene(gameScene);
}

void SceneManager::toIntroScene()
{
	introScene = Scene::create();
	IntroLayer* introLayer = IntroLayer::create();
	introLayer->ptr = this;
	introScene->addChild(introLayer);
	Director::getInstance()->pushScene(introScene);
}

void SceneManager::toSuccessfulScene()
{
	successfulScene = Scene::create();
	SuccessfulLayer* successfulLayer = SuccessfulLayer::create();
	successfulLayer->ptr = this;
	successfulScene->addChild(successfulLayer);
	Director::getInstance()->replaceScene(successfulScene);
}

void SceneManager::toFailedScene()
{
	failedScene = Scene::create();
	FailedLayer* failedLayer = FailedLayer::create();
	failedLayer->ptr = this;
	failedScene->addChild(failedLayer);
	Director::getInstance()->replaceScene(failedScene);
}

void SceneManager::backToFaceScene()
{
	Director::getInstance()->popScene();
}

void SceneManager::toFaceScene()
{
	faceScene = Scene::create();
	auto menuLayer = MenuLayer::create();
	menuLayer->ptr = this;
	faceScene->addChild(menuLayer);
	Director::getInstance()->replaceScene(faceScene);
}