#include "ChooseLayer.h"
#include "GameLayer.h"
#include <iostream>
#include <fstream>
#include <math.h>
#define PI acos(-1)
#define MENU_SCALE 0.3  //�˵���С����
#define MENU_ASLOPE 60.0  //�˵���б��
#define CALC_A 1
#define ANIMATION_DURATION 0.3f  //��������ʱ��
#define CONTENT_SIZE_SCALE (2.0/3)  //�˵�������Ļ�Ĵ�С����
#define ITEM_SIZE_SCALE (1.0/3)  //�˵�����˵��ĳ��ȱ���������һ���˵���ȣ��˵���仯һ����
USING_NS_CC;
using namespace std;

bool ChooseLayer::init()
{
	if (!Layer::init())
	{
		return false;
	}
	index = 0;
	lastIndex = 0;
	this->ignoreAnchorPointForPosition(false);
	selectedItem = nullptr;
	auto size = Director::getInstance()->getWinSize();
	this->setContentSize(size*CONTENT_SIZE_SCALE);
	this->setAnchorPoint(Vec2(0.5f, 0.5f));

	//���������¼�
	auto listener = EventListenerTouchOneByOne::create();
	listener->onTouchBegan = CC_CALLBACK_2(ChooseLayer::onTouchBegan, this);
	listener->onTouchMoved = CC_CALLBACK_2(ChooseLayer::onTouchMoved, this);
	listener->onTouchEnded = CC_CALLBACK_2(ChooseLayer::onTouchEnded, this);
	getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);
	return true;
}

void ChooseLayer::addMenuItem(MenuItem* item)
{
	//���ò˵������꣨���У�
	item->setPosition(this->getContentSize() / 2);
	this->addChild(item);
	items.pushBack(item);
	reset();
	//���ÿ�ʼʱ�ж���Ч��
	updatePositionWithAnimation();
}

void ChooseLayer::updatePosition()
{
	auto menuSize = getContentSize();
	for (int i = 0;i < items.size();i++)
	{
		//����λ��
		float x = calcFunction(i - index, menuSize.width / 2);
		items.at(i)->setPosition(Vec2(menuSize.width / 2 + x, menuSize.height / 2));
		//����zOrder������˳��
		items.at(i)->setZOrder(-abs(i - index) * 100);
		//������������
		items.at(i)->setScale(1.0 - abs(calcFunction(i - index, MENU_SCALE)));
		//������б
		auto orbit1 = OrbitCamera::create(0, 1, 0, calcFunction(i - lastIndex, MENU_ASLOPE), 
			calcFunction(i - lastIndex, MENU_ASLOPE) - calcFunction(i - index, MENU_ASLOPE), 0, 0);
		items.at(i)->runAction(orbit1);
	}
}

void ChooseLayer::updatePositionWithAnimation()
{
	//��ֹͣ���п��ܴ��ڵĶ���
	for (int i = 0;i < items.size();i++)
		items.at(i)->stopAllActions();
	auto menuSize = getContentSize();
	for (int i = 0;i < items.size();i++)
	{
		float x = calcFunction(i - index, menuSize.width / 2);
		items.at(i)->setZOrder(-abs(i - index) * 100);
		//�ƶ�
		auto moveTo = MoveTo::create(ANIMATION_DURATION, Vec2(menuSize.width / 2 + x, menuSize.height / 2));
		items.at(i)->runAction(moveTo);
		//����
		auto scaleTo = ScaleTo::create(ANIMATION_DURATION, (1 - abs(calcFunction(i - index, MENU_SCALE))));
		items.at(i)->runAction(scaleTo);
		//��ת
		auto orbit1 = OrbitCamera::create(ANIMATION_DURATION, 1, 0, calcFunction(i - lastIndex, MENU_ASLOPE),
			calcFunction(i - index, MENU_ASLOPE) - calcFunction(i - lastIndex, MENU_ASLOPE), 0, 0);
		items.at(i)->runAction(orbit1);
	}
	//��ʱ�����ú������ض�ʱ��ֻ����һ��
	scheduleOnce(schedule_selector(ChooseLayer::actionEndCallBack), ANIMATION_DURATION);
}

void ChooseLayer::rectify(bool forward)
{
	auto index = getIndex();
	if (index < 0)
		index = 0;
	if (index > items.size() - 1)
		index = items.size() - 1;
	if (forward)
		index = (int)(index + 0.4);
	else
		index = (int)(index + 0.6);
	setIndex((int)index);
}

void ChooseLayer::reset()
{
	index = 0;
	lastIndex = 0;
}


void ChooseLayer::setIndex(int index)
{
	lastIndex = index;
	this->index = index;
}

float ChooseLayer::getIndex()
{
	//д�ļ�
	ofstream outIndexFile("index.dat", ios::out);
	if (!outIndexFile)
	{
		exit(1);
	}
	outIndexFile << index << endl;
	//д�ļ�����

	return index;
}

cocos2d::MenuItem* ChooseLayer::getCurrentItem()
{
	if (items.size() == 0)
		return nullptr;
	return items.at(index);
}

float ChooseLayer::calcFunction(float index, float width)
{
	return width*index / (abs(index) + CALC_A);
}

bool ChooseLayer::onTouchBegan(Touch* _touch, Event* _event)
{
	//��ֹͣ���п��ܴ��ڵĶ���
	for (int i = 0;i < items.size();i++)
		items.at(i)->stopAllActions();
	if (selectedItem)
		selectedItem->unselected();

	auto position = this->convertToNodeSpace(_touch->getLocation());
	auto size = this->getContentSize();
	auto rect = Rect(0, 0, size.width, size.height);
	if (rect.containsPoint(position))
	{
		return true;
	}
	return false;
}

void ChooseLayer::onTouchEnded(Touch* _touch, Event* _event)
{
	auto size = getContentSize();
	//xDelta��ʾ����x������
	auto xDelta = _touch->getLocation().x - _touch->getStartLocation().x;
	rectify(xDelta > 0);
	if (abs(xDelta) < size.width / 24 && selectedItem)
		selectedItem->activate();
	updatePositionWithAnimation();
}

void ChooseLayer::onTouchMoved(Touch* _touch, Event* _event)
{
	auto size = getContentSize();
	auto xDelta = _touch->getDelta().x;
	lastIndex = index;
	index -= xDelta / (size.width*ITEM_SIZE_SCALE);
	updatePosition();
}

void ChooseLayer::actionEndCallBack(float dx)
{
	selectedItem = getCurrentItem();
	if (selectedItem)
		selectedItem->selected();
}