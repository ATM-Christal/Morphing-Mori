#include "ChooseLayerDemo.h"
#include "MapLayer.h"
#include "GameLayer.h"

Scene* ChooseLayerDemo::createScene()
{
	//����ѡ��mori�ĳ���
	auto scene = Scene::create();
	auto layer = ChooseLayerDemo::create();
	scene->addChild(layer);
	return scene;
}

bool ChooseLayerDemo::init()
{
	if (!Layer::init())
	{
		return false;
	}

	Size visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();

	auto item1 = MenuItemImage::create("mori_blue.png", "mori_blue_selected.png", CC_CALLBACK_1(ChooseLayerDemo::menuItem1CallBack, this));
	auto item2 = MenuItemImage::create("mori_pink.png", "mori_pink_selected.png", CC_CALLBACK_1(ChooseLayerDemo::menuItem2CallBack, this));
	auto item3 = MenuItemImage::create("mori_orange.png", "mori_orange_selected.png", CC_CALLBACK_1(ChooseLayerDemo::menuItem3CallBack, this));
	auto item4 = MenuItemImage::create("mori_yellow.png", "mori_yellow_selected.png", CC_CALLBACK_1(ChooseLayerDemo::menuItem4CallBack, this));

	ChooseLayer* menu = ChooseLayer::create();
	menu->addMenuItem(item1);
	menu->addMenuItem(item2);
	menu->addMenuItem(item3);
	menu->addMenuItem(item4);
	
	menu->setPosition(visibleSize / 2);
	this->addChild(menu, 2);

	//��ɫĪ��
	sprite[0] = Sprite::create("mori_blue.png");
	sprite[0]->setAnchorPoint(Vec2(0.5f, 0.5f));
	sprite[0]->setPosition(visibleSize / 2);
	this->addChild(sprite[0]);
	//��ɫĪ��
	sprite[1] = Sprite::create("mori_pink.png");
	sprite[1]->setAnchorPoint(Vec2(0.5f, 0.5f));
	sprite[1]->setPosition(visibleSize / 2);
	this->addChild(sprite[1]);
	//��ɫĪ��
	sprite[2] = Sprite::create("mori_orange.png");
	sprite[2]->setAnchorPoint(Vec2(0.5f, 0.5f));
	sprite[2]->setPosition(visibleSize / 2);
	this->addChild(sprite[2]);
	//��ɫĪ��
	sprite[3] = Sprite::create("mori_yellow.png");
	sprite[3]->setAnchorPoint(Vec2(0.5f, 0.5f));
	sprite[3]->setPosition(visibleSize / 2);
	this->addChild(sprite[3]);

	hideAllSprite();

	//�Խڵ���ʽ���س���
	Node* node = CSLoader::createNode("ChooseScene.csb");

	//��ȡlayer����ͨ��name���ԣ�ͨ��tag�в���bug��
	Layout* layout = static_cast<Layout *>(node->getChildByName("Panel_1"));

	Button* button = static_cast<Button *>(layout->getChildByTag(1));
	button->addTouchEventListener(CC_CALLBACK_2(ChooseLayerDemo::touchCallBack, this));
	//���ڵ���뵽����
	this->addChild(node);
	
	return true;
}

void ChooseLayerDemo::touchCallBack(Ref* sender, Widget::TouchEventType controlEvent)
{
	//������ڴ������������Ӧ
	if (controlEvent == Widget::TouchEventType::ENDED)
	{
		auto button = static_cast<Button*>(sender);
		if (button->getTag() == 1)
			ptr->toGameScene();
	}
}

void ChooseLayerDemo::menuCloseCallBack(Ref* sender)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
    MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.", "Alert");
    return;
#endif

    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}

void ChooseLayerDemo::menuItem1CallBack(Ref* sender)
{
	hideAllSprite();
	sprite[0]->setVisible(true);
}
void ChooseLayerDemo::menuItem2CallBack(Ref* sender)
{
	hideAllSprite();
	sprite[1]->setVisible(true);
}

void ChooseLayerDemo::menuItem3CallBack(Ref* sender)
{
	hideAllSprite();
	sprite[2]->setVisible(true);
}

void ChooseLayerDemo::menuItem4CallBack(Ref* sender)
{
	hideAllSprite();
	sprite[3]->setVisible(true);
}

void ChooseLayerDemo::hideAllSprite()
{
	for (auto p : sprite)
		if (p->isVisible())
			p->setVisible(false);
}